var a = 60;
document.getElementById("test").innerHTML = fgf;
document.getElementById("number").innerHTML =  a;